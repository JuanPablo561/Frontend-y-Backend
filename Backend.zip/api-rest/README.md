# REST-API con Node.js, Express y PostgreSQL

Backend de la práctica, integrado con el frontend (HTML+CSS+JS) del
repositorio "Pr-ctica-con-HTML".

## Instalación
```bash
npm install
cp .env.example .env     # y edita tus credenciales de PostgreSQL
psql -U postgres -f sql/schema.sql
npm run dev
```

El servidor queda en `http://localhost:3000`. El frontend (por ejemplo con
Live Server en `http://127.0.0.1:5500`) le hace peticiones `fetch` a esa URL.
Si cambias el puerto o el origen del frontend, actualiza `FRONTEND_ORIGIN`
en `.env` y `API_BASE_URL` en `config.js` del frontend.

## Rutas
| Método | Ruta         | Descripción                    |
|--------|--------------|---------------------------------|
| GET    | /            | Bienvenida                     |
| GET    | /marco       | Responde `polo`                |
| GET    | /ping        | Responde `pong` + prueba de BD |
| GET    | /users       | Lista usuarios                 |
| GET    | /users/:id   | Obtiene un usuario             |
| POST   | /users       | Crea usuario (usado por el registro del frontend) |
| PUT    | /users/:id   | Actualiza usuario              |
| DELETE | /users/:id   | Elimina usuario                |
| POST   | /login       | Usado por el login del frontend (email + password) |

## Pruebas rápidas (curl)
```bash
curl http://localhost:3000/marco
curl http://localhost:3000/ping

curl -X POST http://localhost:3000/users -H "Content-Type: application/json" \
  -d '{"name":"Ana","email":"ana@mail.com","password":"1234"}'

curl http://localhost:3000/users

curl -X POST http://localhost:3000/login -H "Content-Type: application/json" \
  -d '{"email":"ana@mail.com","password":"1234"}'
```
