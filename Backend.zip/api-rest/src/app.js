const express = require('express');
const morgan = require('morgan');
const cors = require('cors');

const { frontendOrigin } = require('./config');
const indexRoutes = require('./routes/index.routes');
const usersRoutes = require('./routes/users.routes');
const authRoutes = require('./routes/auth.routes');

const app = express();

app.use(morgan('dev'));
// Habilita que el frontend (otro origen/puerto) pueda llamar a esta API
app.use(cors({ origin: frontendOrigin }));
app.use(express.json());

app.use(indexRoutes);
app.use(usersRoutes);
app.use(authRoutes);

// 404
app.use((req, res) => {
  res.status(404).json({ message: 'Ruta no encontrada' });
});

module.exports = app;
