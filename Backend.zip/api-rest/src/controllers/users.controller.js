const { pool } = require('../database/connection');
const { hashPassword } = require('../utils/password');

// 23505 = violación de restricción UNIQUE en PostgreSQL
const isDuplicateEmail = (error) => error.code === '23505';

// GET /users
const getUsers = async (req, res) => {
  try {
    const result = await pool.query(
      'SELECT id, name, email, created_at FROM users ORDER BY id',
    );
    res.json(result.rows);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// GET /users/:id
const getUser = async (req, res) => {
  try {
    const result = await pool.query(
      'SELECT id, name, email, created_at FROM users WHERE id = $1',
      [req.params.id],
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ message: 'Usuario no encontrado' });
    }
    res.json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// POST /users
const createUser = async (req, res) => {
  const { name, email, password } = req.body;
  if (!name || !email || !password) {
    return res.status(400).json({ message: 'name, email y password son obligatorios' });
  }

  try {
    const result = await pool.query(
      `INSERT INTO users (name, email, password)
       VALUES ($1, $2, $3)
       RETURNING id, name, email, created_at`,
      [name, email, hashPassword(password)],
    );
    res.status(201).json(result.rows[0]);
  } catch (error) {
    if (isDuplicateEmail(error)) {
      return res.status(409).json({ message: 'El email ya está registrado' });
    }
    res.status(500).json({ message: error.message });
  }
};

// PUT /users/:id
const updateUser = async (req, res) => {
  const { name, email, password } = req.body;
  if (!name || !email) {
    return res.status(400).json({ message: 'name y email son obligatorios' });
  }

  try {
    const result = await pool.query(
      `UPDATE users
       SET name = $1, email = $2, password = COALESCE($3, password)
       WHERE id = $4
       RETURNING id, name, email, created_at`,
      [name, email, password ? hashPassword(password) : null, req.params.id],
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ message: 'Usuario no encontrado' });
    }
    res.json(result.rows[0]);
  } catch (error) {
    if (isDuplicateEmail(error)) {
      return res.status(409).json({ message: 'El email ya está registrado' });
    }
    res.status(500).json({ message: error.message });
  }
};

// DELETE /users/:id
const deleteUser = async (req, res) => {
  try {
    const result = await pool.query(
      'DELETE FROM users WHERE id = $1 RETURNING id',
      [req.params.id],
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ message: 'Usuario no encontrado' });
    }
    res.json({ message: 'Usuario eliminado', id: result.rows[0].id });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = { getUsers, getUser, createUser, updateUser, deleteUser };
