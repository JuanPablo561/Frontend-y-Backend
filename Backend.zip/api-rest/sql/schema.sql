-- Ejecuta esto conectado a PostgreSQL (psql, pgAdmin, DBeaver, etc.)

CREATE DATABASE apidb;

-- Conéctate a la base apidb antes de correr lo siguiente (\c apidb en psql)

CREATE TABLE IF NOT EXISTS users (
  id         SERIAL PRIMARY KEY,
  name       VARCHAR(100) NOT NULL,
  email      VARCHAR(150) NOT NULL UNIQUE,
  password   VARCHAR(255) NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);
