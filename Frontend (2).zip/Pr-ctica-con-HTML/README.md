# Frontend - Práctica con HTML + CSS + JS

Frontend integrado con la REST-API (Node.js + Express + PostgreSQL) del
repositorio "api-rest".

## Cómo correrlo
1. Asegúrate de que el backend esté corriendo (por defecto en `http://localhost:3000`).
   Si usas otro host/puerto, cámbialo en `config.js`.
2. Abre este proyecto con un servidor estático (por ejemplo la extensión
   "Live Server" de VS Code, o `npx serve`). No uses doble clic en el HTML
   directamente si tu navegador bloquea `fetch` desde `file://`.
3. Ve a `index.html`.

## Flujo de integración con el backend
- **Crear cuenta** (`index.html`): el formulario "Crear cuenta" hace
  `POST /users` a la API para registrar un usuario nuevo (nombre, correo,
  contraseña).
- **Iniciar sesión** (`index.html`): el formulario de login hace
  `POST /login` con `email` y `password`. Si es correcto, guarda al usuario
  en `sessionStorage` y redirige a `profile.html`.
- **Perfil** (`profile.html`): lee el usuario desde `sessionStorage` y
  muestra su nombre, correo y fecha de registro reales (si no hay sesión,
  redirige de vuelta al login). Incluye botón "Cerrar sesión".

Las demás páginas (`tags.html`, `form.html`) no cambiaron: siguen siendo
ejercicios independientes de HTML/JS.

## Archivos relevantes para la integración
- `config.js`: define `API_BASE_URL`.
- `script.js`: lógica de login, registro y perfil contra la API.
