// URL base de la REST-API (backend Node.js + Express + PostgreSQL)
// Si despliegas el backend en otro host/puerto, cambia solo esta línea.
const API_BASE_URL = "http://localhost:3000";
